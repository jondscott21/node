var math_module = require('./mathlib')();

console.log(math_module.add(4, 2));
console.log(math_module.multiply(4, 2));
console.log(math_module.square(5));
console.log(math_module.random(1, 20));